package com.example.hp.myapplication;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Button m1=(Button)findViewById(R.id.m1);
        Button m2=(Button)findViewById(R.id.m2);
        Button m3=(Button)findViewById(R.id.m3);
        Button m4=(Button)findViewById(R.id.m4);
        //Button m4=(Button)findViewById(R.id.m4);

        final EditText nametext=(EditText)findViewById(R.id.editName);

        m1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=nametext.getText().toString();
                Intent intent=new Intent(getApplicationContext(),QuestionsActivity1.class);
                intent.putExtra("myname",name);
                startActivity(intent);
            }
        });

        m2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=nametext.getText().toString();

                Intent intent=new Intent(getApplicationContext(),QuestionsActivity2.class);
                intent.putExtra("myname",name);

                startActivity(intent);
            }
        });
        m3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=nametext.getText().toString();
                Intent intent=new Intent(getApplicationContext(),QuestionsActivity.class);
                intent.putExtra("myname",name);
                startActivity(intent);
            }
        });

        m4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=nametext.getText().toString();
                Intent intent=new Intent(getApplicationContext(),QuestionsActivity4.class);
                intent.putExtra("myname",name);
                startActivity(intent);
            }
        });






    }
}
